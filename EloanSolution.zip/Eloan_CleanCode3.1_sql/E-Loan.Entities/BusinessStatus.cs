﻿namespace E_Loan.Entities
{
    public enum BusinessStatus
    {
        Individual = 1,
        Organisation = 2
    }
}
